import React from "react";
import HomeScreen from "./screens/HomeScreen";

const App = () => {
    return (
        <>
            <HomeScreen />
        </>
    );
};

export default App;
