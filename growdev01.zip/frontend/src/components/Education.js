import React from "react";

const Education = () => {
    return (
        <div>
            <h2>Educação</h2>
            <hr></hr>
            <h3>QI Faculdade & Escola Técnica - 2021</h3>
            <p>
                Análise e Desenvolvimento de Sistemas - Em andamento, segundo
                semestre
            </p>
            <h3>GrowDev - 2021</h3>
            <p>
                4º Programa Starter: Formação Completa em Desenvolvimento Web
                FullStack (andamento)
            </p>
            <h3>Coursera/Google - 2019</h3>
            <p>Fundamentos de Suporte Técnico em TI</p>
            <h3>Senac Informática - 2013</h3>
            <p>Curso "Desenvolvedor de Games" - 240 horas</p>
        </div>
    );
};

export default Education;
